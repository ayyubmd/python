update list set tenant = 'gg' where tenant = 'default';
