sudo apt-get install postgresql-client -y &&
echo "Installing Postgres-Client" &&
sleep 3 &&
echo "`psql --version` installed" &&
sudo service vimond-cms-service stop &&
sleep 6 &&
cd /etc/init && sudo expect -f /usr/local/share/get.sh home/Release-1.9.3/CMS/ENV/vimond-cms-service.conf &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.3/CMS/ENV/psql_update.sql &&
cd /opt && sudo chown -R vimond-cms-service:vimond-cms-service vimond-cms-service &&
PGPASSWORD=watchable psql --host prodvccdb.csziq9cqsaej.us-east-1.rds.amazonaws.com --port 5432 --username=vimond --dbname vccdb < /tmp/psql_update.sql &&
cd /tmp && sudo rm psql_update.sql &&
echo "uninstalling postgresql-client..." &&
sleep 3 &&
sudo apt-get remove postgresql-client -y &&
sudo service vimond-cms-service start &&
sleep 4 &&
curl localhost:10014/cms/version
