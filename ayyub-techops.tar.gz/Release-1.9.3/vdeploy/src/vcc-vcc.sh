sudo service unicorn_GoldenGateVCC2 stop &&
sleep 2 &&
cd /home/sites/GoldenGateVCC2/releases/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.3/VCC/vcc-rails-1.9.3.tgz &&
cd /home/sites/GoldenGateVCC2/releases/ && sudo tar zxvf vcc-rails-1.9.3.tgz -C /home/sites/GoldenGateVCC2/releases/ &&
cd /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739/config && sudo mv settings.yml settings.yml_bak &&
cd /home/sites/GoldenGateVCC2/shared/config/ && sudo mv settings.yml settings.yml_`date +"%d-%m-%Y"` &&
cd /home/sites/GoldenGateVCC2/shared/config/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.3/VCC/ENV/settings.yml &&
cd /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739/config && sudo ln -s /home/sites/GoldenGateVCC2/shared/config/settings.yml &&
cd /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739/config && sudo mv application.yml application.yml_bak &&
cd /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739/config && sudo ln -s /home/sites/GoldenGateVCC2/shared/config/application.yml &&
cd /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739 && sudo mv log log_bak &&
cd /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739 && sudo ln -s /home/sites/GoldenGateVCC2/shared/log &&
cd /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739 && sudo mkdir -p tmp/cache &&
cd /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739/tmp && sudo ln -s /home/sites/GoldenGateVCC2/shared/pids &&
sudo chown -R gg_deployer:gg_deployer /home/sites/GoldenGateVCC2/shared/config/ &&
sudo chown -R gg_deployer:gg_deployer /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739 &&
sudo -S su - gg_deployer -c "cd /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739 && bundle install --without development test" &&
cd /home/sites/GoldenGateVCC2/ && sudo rm current &&
cd  /home/sites/GoldenGateVCC2/ && sudo -S su -c "ln -s /home/sites/GoldenGateVCC2/releases/vcc-rails-1.9.3/201609220739/ current" -s /bin/sh gg_deployer &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.3/VCC/vcc-content-organizer-1.9.3.tgz &&
cd /tmp && sudo tar -xvf vcc-content-organizer-1.9.3.tgz -C /home/sites &&
sudo chown -R www-data:www-data /home/sites/vcc-content-organizer-1.9.3 &&
cd /home/sites/ && sudo rm organizer &&
cd /home/sites/ && sudo ln -s vcc-content-organizer-1.9.3 organizer &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.3/VCC/vcc-editorial-1.9.3.tgz  &&
cd /tmp && sudo tar -xvf vcc-editorial-1.9.3.tgz -C /home/sites &&
sudo chown -R www-data:www-data /home/sites/vcc-editorial-1.9.3 &&
cd /home/sites/ && sudo rm editorial &&
cd /home/sites/ && sudo ln -s vcc-editorial-1.9.3 editorial &&
cd /home/sites/common && sudo chown -R www-data:www-data . &&
sleep 4 &&
sudo service nginx restart &&
sleep 6 &&
sudo service unicorn_GoldenGateVCC2 start
