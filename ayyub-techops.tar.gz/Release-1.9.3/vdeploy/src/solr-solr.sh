sudo stop solr &&
sleep 4 &&
cd /opt/solr/vimond/lib/ && sudo rm vimond-solr.jar &&
cd /opt/solr/vimond/lib/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.3/solr/vimond-solr.jar &&
sudo rm /opt/solr/vimond/lib/ojdbc6-11.2.0.3.jar &&
cd /opt/solr/vimond/lib/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.3/solr/ojdbc7-12.1.0.1.jar
cd /opt/ && sudo expect -f /usr/local/share/get.sh /home/Release-1.9.3/solr/ENV/solrconf.tgz &&
cd /opt/ && sudo expect -f /usr/local/share/get.sh /home/Release-1.9.3/solr/ENV/solrconfig.sh &&
cd /opt/ && sudo tar xzf solrconf.tgz &&
cd /opt/solrconf/adminSearch/ && sudo cp -r * /opt/solr/vimond/solr/adminSearch/conf/ &&
cd /opt/solrconf/userSearch/ && sudo cp -r * /opt/solr/vimond/solr/userSearch/conf/ &&
cd /opt/ && sudo bash solrconfig.sh &&
sudo start solr
