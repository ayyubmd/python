sudo service webserver stop &&
sleep 4 &&
sudo service varnish stop &&
sleep 4 &&
cd /home/ubuntu/current/GoldenGate/app/assets/javascripts/analytics/ && sudo mv eventReporter.js eventReporter.js-`date +"%d-%m-%Y"` &&
cd /home/ubuntu/current/GoldenGate/app/assets/javascripts/analytics/ && sudo expect -f /usr/local/share/get.sh home/Webserver-4.1/hotfix2/eventReporter.js &&
cd /home/ubuntu/current/GoldenGate/app/assets/javascripts/analytics/ && sudo chown -R ubuntu:ubuntu eventReporter.js &&
sudo -S su - ubuntu -c "cd /home/ubuntu/current/GoldenGate/ && RAILS_Techops=production bundle exec rake assets:precompile;bundle exec rails s puma -d -p 3100 -e production" &&
sleep 4 &&
sudo service varnish start &&
sleep 6 &&
echo -n  "Performing Healthcheck : " &&
curl localhost:3100/api/ping &&
exit
