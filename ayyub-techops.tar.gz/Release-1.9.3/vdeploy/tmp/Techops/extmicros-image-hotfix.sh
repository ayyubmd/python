sudo service vimondImageService stop &&
sleep 6 &&
cd /home/deploy-vis && sudo expect -f /usr/local/share/get.sh home/Release-1.9.3/externalmicros/Image/vimondImageService-2.2.2-8-g73b6fc2.zip &&
cd /home/deploy-vis && sudo unzip vimondImageService-2.2.2-8-g73b6fc2.zip &&
cd /home/deploy-vis/VimondImageService-2.2.2-8-g73b6fc2 && sudo mkdir logs &&
cd /home/deploy-vis && sudo rm vimondimageservice-current &&
cd /home/deploy-vis && sudo ln -s VimondImageService-2.2.2-8-g73b6fc2 vimondimageservice-current &&
cd /home/deploy-vis && sudo cp -p VimondImageService-2.2.1-3-gd4fa43f/start.sh VimondImageService-2.2.2-8-g73b6fc2/start.sh &&
cd /home/deploy-vis && sudo cp -p VimondImageService-2.2.1-3-gd4fa43f/config.conf VimondImageService-2.2.2-8-g73b6fc2/config.conf &&
cd /home/deploy-vis && sudo cp -p VimondImageService-2.2.1-3-gd4fa43f/config.conf VimondImageService-2.2.2-8-g73b6fc2/stop.sh &&
sudo chown -R deploy-vis:deploy-vis /home/deploy-vis/ &&
sleep 3 &&
sudo service vimondImageService start &&
sleep 6 &&
echo -n " " &&
curl localhost:19000/api/ping &&
exit
