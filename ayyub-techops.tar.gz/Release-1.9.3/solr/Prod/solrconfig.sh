#!/bin/bash
ZOOIP=172.31.3.54:2181,172.31.3.51:2181,172.31.3.52:2181/solr &&
sudo /opt/solr/vimond/scripts/cloud-scripts/zkcli.sh -zkhost ${ZOOIP} -cmd upconfig -confdir /opt/solr/vimond/solr/adminSearch/conf -confname adminSearch &&
sudo /opt/solr/vimond/scripts/cloud-scripts/zkcli.sh -zkhost ${ZOOIP} -cmd linkconfig -collection adminSearch -confname adminSearch &&
sudo /opt/solr/vimond/scripts/cloud-scripts/zkcli.sh -zkhost ${ZOOIP} -cmd upconfig -confdir /opt/solr/vimond/solr/userSearch/conf -confname userSearch &&
sudo /opt/solr/vimond/scripts/cloud-scripts/zkcli.sh -zkhost ${ZOOIP} -cmd linkconfig -collection userSearch -confname userSearch
