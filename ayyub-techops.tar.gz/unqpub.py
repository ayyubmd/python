import xlrd
import csv
import sets
import sys
from os import sys

def unique(excel_file):

    wb = xlrd.open_workbook(excel_file)
    sh = wb.sheet_by_index(0)
    publisher = set([])

    for rownum in xrange(sh.nrows):
	if sh.cell(rownum, 0).value != xlrd.empty_cell.value:
		cellvalue = sh.cell(rownum,0).value
		cellvalue = cellvalue.encode('utf8')
#		print cellvalue
		publisher.add(cellvalue)
#    print str(publisher)
     
    sys.stdout = open('pubdetails', 'w')
    print "\n".join(publisher)

    publen = len(publisher)

if __name__ == "__main__":
    unique(sys.argv[1])
