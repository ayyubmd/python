file = open("Vox Media.csv", "w")
for line in open("your_csv_file.csv"):
 if "Vox Media" in line:
   file.write(line)
file.close()
