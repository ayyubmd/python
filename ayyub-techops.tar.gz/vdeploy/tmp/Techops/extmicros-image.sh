cd /home/deploy-vis && sudo wget https://readonly:AP8PL4Xeyns58vTEE1HZBX1cBQdATj9g5gzuMk@vimond.artifactoryonline.com/vimond/libs-releases-local/com/vimond/service/vimondImageService/2.2.2-9-gff2afb9/vimondImageService-2.2.2-9-gff2afb9.zip &&
sudo service vimondImageService stop &&
sleep 10 &&
cd /home/deploy-vis && sudo unzip vimondImageService-2.2.2-9-gff2afb9.zip &&
cd /home/deploy-vis && sudo cp -p vimondimageservice-current/start.sh VimondImageService-2.2.2-9-gff2afb9/ &&
cd /home/deploy-vis && sudo cp vimondimageservice-current/config.conf VimondImageService-2.2.2-9-gff2afb9/ &&
cd /home/deploy-vis && sudo rm vimondimageservice-current &&
cd /home/deploy-vis && sudo ln -s VimondImageService-2.2.2-9-gff2afb9 vimondimageservice-current &&
cd /home/deploy-vis && sudo chown -R deploy-vis:deploy-vis VimondImageService-2.2.2-9-gff2afb9 vimondimageservice-current &&
sudo service vimondImageService start
