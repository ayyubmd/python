sudo service tomcat7 stop &&
sleep 10 &&
sudo mv /usr/local/tomcat/webapps/ROOT.war /usr/local/tomcat/ROOT.war_`date +"%m-%d-%Y"` &&
sudo rm -rf /usr/local/tomcat/webapps/ROOT &&
cd /usr/local/tomcat/webapps/ && sudo wget https://readonly:AP8PL4Xeyns58vTEE1HZBX1cBQdATj9g5gzuMk@vimond.artifactoryonline.com/vimond/libs-releases-local/CoreAdmin/admin/4.10.1-6-g9a373e5.b162/admin-4.10.1-6-g9a373e5.b162.war &&
cd /usr/local/tomcat/webapps/ && sudo mv admin-4.10.1-6-g9a373e5.b162.war ROOT.war &&
cd /usr/local/tomcat/webapps/ && sudo chown -R tomcat:tomcat ROOT.war &&
sudo service tomcat7 start
