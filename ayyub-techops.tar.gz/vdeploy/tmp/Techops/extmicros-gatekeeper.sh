cd /opt/vimond-gatekeeper/ && sudo wget https://readonly:AP8PL4Xeyns58vTEE1HZBX1cBQdATj9g5gzuMk@vimond.artifactoryonline.com/vimond/libs-releases-local/com/vimond/service/gatekeeper/vimond-gatekeeper-service/3.10.164/vimond-gatekeeper-service-3.10.164.jar &&
sudo stop vimond-gatekeeper-service &&
sleep 10 &&
cd /opt/vimond-gatekeeper/ && sudo rm vimond-gatekeeper-service.jar && sudo ln -s vimond-gatekeeper-service-3.10.164.jar vimond-gatekeeper-service.jar &&
cd /opt/vimond-gatekeeper/ && sudo chown -R vimond-gatekeeper:vimond-api vimond-gatekeeper-service-3.10.164.jar vimond-gatekeeper-service.jar &&
sudo start vimond-gatekeeper-service &&
sleep 15 &&
echo "Checking healthcheck -- " && curl -s localhost:8083/healthcheck?pretty=true && echo "" &&
echo -n "Checking version of vimond-gatekeeper-service -- 3.10.164 " && echo "" && curl -s localhost:8082/version &&
echo "" && echo "Upgrade Completed"
