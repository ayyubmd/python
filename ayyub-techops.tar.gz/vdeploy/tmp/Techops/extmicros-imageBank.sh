cd /opt/vimond-image-bank-service && sudo wget https://readonly:AP8PL4Xeyns58vTEE1HZBX1cBQdATj9g5gzuMk@vimond.artifactoryonline.com/vimond/libs-releases-local/vimond-image-bank-service/1.0.0-6-g88b1cfa.b167/vimond-image-bank-service-1.0.0-6-g88b1cfa.b167.jar &&
sudo stop vimond-image-bank-service &&
sleep 15 &&
cd /opt/vimond-image-bank-service && sudo rm vimond-image-bank-service.jar && sudo ln -s vimond-image-bank-service-1.0.0-6-g88b1cfa.b167.jar vimond-image-bank-service.jar &&
cd /opt/vimond-image-bank-service && sudo chown -R vimond-image-bank-service:vimond-api vimond-image-bank-service-1.0.0-6-g88b1cfa.b167.jar vimond-image-bank-service.jar &&
sudo start vimond-image-bank-service &&
sleep 15 &&
echo "Checking healthcheck on vimond-image-bank-service.. " && curl -s localhost:8149/healthcheck?pretty=true && echo "" &&
echo -n "Checking Version of vimond-image-bank-service : 1.0.0-6-g88b1cfa.b167 -- " && curl -s localhost:8148/version && echo "" &&
echo "Upgrade Completed"
