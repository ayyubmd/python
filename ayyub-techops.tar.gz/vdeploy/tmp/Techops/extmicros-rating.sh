cd /opt/vimond-rating-service/ && sudo wget https://readonly:AP8PL4Xeyns58vTEE1HZBX1cBQdATj9g5gzuMk@vimond.artifactoryonline.com/vimond/libs-releases-local/com/vimond/service/vimond-rating-service/1.2.2-8-g4e401f7.b40/vimond-rating-service-1.2.2-8-g4e401f7.b40.jar &&
sudo stop vimond-rating-service &&
sleep 10 &&
cd /opt/vimond-rating-service/ && sudo rm vimond-rating-service.jar &&
cd /opt/vimond-rating-service/ && sudo ln -s vimond-rating-service-1.2.2-8-g4e401f7.b40.jar vimond-rating-service.jar && sudo chown -R vimond-rating-service:vimond-api . &&
sudo start vimond-rating-service && sleep 15 &&
echo "Checking healthcheck vimond-rating-service -- " && curl -s localhost:8089/healthcheck?pretty=true && echo "" &&
echo -n "Checking Verion on vimond-rating-service -- 1.2.2-8-g4e401f7.b40 ----> " && curl -s localhost:8088/version && echo "" &&
echo "Upgrade Completed"
