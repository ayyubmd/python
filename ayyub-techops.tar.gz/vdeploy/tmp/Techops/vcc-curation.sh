cd /opt/vimond-vcc-curation-service && sudo wget http://docs:undocumented@files.vimond.com/vimond_release/1.11.0/vcc/vcc-curation-v1.1.0-115-gd4a32a5.tgz &&
cd /opt/vimond-vcc-curation-service && sudo tar xvf vcc-curation-v1.1.0-115-gd4a32a5.tgz &&
sudo service vimond-vcc-curation-service stop &&
sleep 10 &&
cd /opt/vimond-vcc-curation-service && sudo rm vimond-vcc-curation-current &&
cd /opt/vimond-vcc-curation-service && sudo ln -s vcc-curation-v1.1.0-115-gd4a32a5/server/ vimond-vcc-curation-current &&
cd /opt/vimond-vcc-curation-service && sudo chown -R vimond-vcc-curation-service:vimond-cms-service . &&
echo "Taking backup vimond-vcc-curation-service.conf file...." &&
sudo cp -p /etc/init/vimond-vcc-curation-service.conf /home/ayyub/vimond-vcc-curation-service.conf-`date +"%d-%m-%Y"` &&
echo "Copying New curationg conf file to /etc/init/...." &&
sudo cp -p /home/ayyub/v1.11.0/vimond-vcc-curation-service.conf /etc/init/vimond-vcc-curation-service.conf &&
sudo service vimond-vcc-curation-service start
