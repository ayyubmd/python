sudo service unicorn_GoldenGateVCC2 stop &&
sleep 10 &&
sudo apt-get -y install cmake pkg-config &&
sleep 2 &&
cd /home/sites/ && sudo wget http://docs:undocumented@files.vimond.com/vimond_release/1.11.0/vcc/vcc-rails-1.11.0.tgz &&
cd /home/sites/ && sudo wget http://docs:undocumented@files.vimond.com/vimond_release/1.11.0/vcc/vcc-approval-1.11.0.tgz &&
cd /home/sites/ && sudo wget http://docs:undocumented@files.vimond.com/vimond_release/1.11.0/vcc/vcc-content-organizer-1.11.0.tgz &&
cd /home/sites/ && sudo wget http://docs:undocumented@files.vimond.com/vimond_release/1.11.0/vcc/vcc-video-monitoring-1.11.0.tgz &&
cd /home/sites/ && sudo wget http://docs:undocumented@files.vimond.com/vimond_release/1.11.0/vcc/vcc-editorial-1.11.0-toggled-on.tgz &&
cd /home/sites/ && sudo wget http://docs:undocumented@files.vimond.com/vimond_release/1.11.0/vcc/vcc-user-profile-1.11.0.tgz &&
cd /home/sites/ && sudo tar zxvf vcc-rails-1.11.0.tgz -C /home/sites/GoldenGateVCC2/releases/ &&
cd /home/sites/GoldenGateVCC2/ && sudo rm current &&
cd /home/sites/GoldenGateVCC2/ && sudo ln -s /home/sites/GoldenGateVCC2/releases/vcc-rails-1.10.0-68-g45adc56-updatedToggles/201701020706/ current &&
cd /home/sites/GoldenGateVCC2/shared/config/ && sudo mv settings.yml settings.yml-`date +"%d-%m-%Y"` &&
sudo cp -p /home/ayyub/v1.11.0/settings.yml /home/sites/GoldenGateVCC2/shared/config/ &&
cd /home/sites/GoldenGateVCC2/current/config && sudo mv settings.yml settings.yml_bak &&
sudo ln -s /home/sites/GoldenGateVCC2/shared/config/settings.yml &&
cd /home/sites/GoldenGateVCC2/current/config && sudo mv application.yml application.yml_bak &&
sudo ln -s /home/sites/GoldenGateVCC2/shared/config/application.yml &&
cd /home/sites/GoldenGateVCC2/current/ && sudo mv log log_bak &&
sudo ln -s /home/sites/GoldenGateVCC2/shared/log &&
cd /home/sites/GoldenGateVCC2/current/ && sudo mkdir -p tmp/cache &&
cd /home/sites/GoldenGateVCC2/current/tmp && sudo ln -s /home/sites/GoldenGateVCC2/shared/pids &&
sudo chown -R gg_deployer:gg_deployer /home/sites/GoldenGateVCC2/releases/vcc-rails-1.10.0-68-g45adc56-updatedToggles/ /home/sites/GoldenGateVCC2/current/ &&
sudo -S su - gg_deployer -c "cd /home/sites/GoldenGateVCC2/releases/vcc-rails-1.10.0-68-g45adc56-updatedToggles/201701020706/ && bundle install --without development test" &&
cd /home/sites/ && sudo tar -xvf vcc-approval-1.11.0.tgz  -C . &&
cd /home/sites/ && sudo tar -xvf vcc-content-organizer-1.11.0.tgz  -C . &&
cd /home/sites/ && sudo tar -xvf vcc-video-monitoring-1.11.0.tgz  -C . &&
cd /home/sites/ && sudo tar -xvf vcc-editorial-1.11.0-toggled-on.tgz  -C . &&
cd /home/sites/ && sudo tar -xvf vcc-user-profile-1.11.0.tgz -C . &&
cd /home/sites/ && sudo chown -R www-data:www-data vcc-approval-v1.2.7-31-gae0d8d0-updatedToggles &&
cd /home/sites/ && sudo chown -R www-data:www-data vcc-content-organizer-ecf260d-updatedToggles &&
cd /home/sites/ && sudo chown -R www-data:www-data vcc-video-monitoring-v1.5.8-2-g991c16b &&
cd /home/sites/ && sudo chown -R www-data:www-data vcc-editorial-7772e3c &&
cd /home/sites/ && sudo chown -R www-data:www-data vcc-user-profile-0.4.0-6-g01a125f &&
cd /home/sites/ && sudo rm approval &&
cd /home/sites/ && sudo ln -s vcc-approval-v1.2.7-31-gae0d8d0-updatedToggles approval &&
cd /home/sites/ && sudo rm organizer &&
cd /home/sites/ && sudo ln -s vcc-content-organizer-ecf260d-updatedToggles organizer &&
cd /home/sites/ && sudo rm monitoring &&
cd /home/sites/ && sudo ln -s vcc-video-monitoring-v1.5.8-2-g991c16b monitoring &&
cd /home/sites/ && sudo rm editorial &&
cd /home/sites/ && sudo ln -s vcc-editorial-7772e3c editorial &&
cd /home/sites/ && sudo ln -s vcc-user-profile-0.4.0-6-g01a125f user-profile &&
echo "Taking back up of GoldenGateVCC2 nginx configuration file" &&
sudo cp -p /etc/nginx/sites-enabled/GoldenGateVCC2 && sudo cp -p /etc/nginx/GoldenGateVCC2-`date +"%d-%m-%Y"` &&
echo "Copying new nginx GoldenGateVCC2 configuration file" &&
sudo cp -p /home/ayyub/v1.11.0/GoldenGateVCC2 /etc/nginx/sites-enabled/GoldenGateVCC2 &&
echo "Starting VCC Server....!" && echo "" &&
sleep 10 &&
sudo service unicorn_GoldenGateVCC2 start &&
sleep 15 &&
sudo service nginx restart &&
sleep 4 &&
sudo service memcached restart
