cd /opt/asset-importer-service &&  sudo wget https://readonly:AP8PL4Xeyns58vTEE1HZBX1cBQdATj9g5gzuMk@vimond.artifactoryonline.com/vimond/libs-releases-local/com/vimond/service/AssetImporterService/ais-all-in-one-service/3.3.9-8-g7263e88.b163/ais-all-in-one-service-3.3.9-8-g7263e88.b163.jar &&
sudo service vimond-asset-importer-service stop &&
sleep 10 &&
cd /opt/asset-importer-service && sudo rm vimond-asset-importer-service.jar &&
cd /opt/asset-importer-service && sudo ln -s ais-all-in-one-service-3.3.9-8-g7263e88.b163.jar vimond-asset-importer-service.jar &&
cd /opt/asset-importer-service && sudo chown -R asset-importer-service:asset-importer-service . &&
sleep 5 &&
echo "Starting the Asset Importer Service" &&
sudo service vimond-asset-importer-service start &&
sleep 10 &&
echo "Perfroming Checking health..." &&
sleep 10 &&
curl -s localhost:14500/healthcheck?pretty=true && echo "" &&
echo "Checking Version -- 3.3.9-8-g7263e88.b163 -- " && echo "" &&
curl -s localhost:4500/version && echo "" &&
echo "Upgrade Completed..."
