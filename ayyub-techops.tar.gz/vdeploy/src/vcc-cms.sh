cd /opt/vimond-cms-service/ && sudo wget https://readonly:AP8PL4Xeyns58vTEE1HZBX1cBQdATj9g5gzuMk@vimond.artifactoryonline.com/vimond/packaged-releases-local/com/vimond/vimond-cms/vimond-cms-5b7c3e8.tgz &&
cd /opt/vimond-cms-service/ && sudo tar xvfz vimond-cms-5b7c3e8.tgz &&
sudo service vimond-cms-service stop &&
sleep 10 &&
cd /opt/vimond-cms-service/ && sudo rm vimond-cms-current &&
cd /opt/vimond-cms-service/ && sudo ln -fns vimond-cms-5b7c3e8 vimond-cms-current &&
echo "Taking backup of cms configuration file" && echo "" && sudo cp -p /etc/init/vimond-cms-service.conf /home/ayyub/vimond-cms-service.conf-`date +"%d-%m-%Y"` &&
echo "Copying new cms start conf file" && sudo cp -p /home/ayyub/v1.11.0/vimond-cms-service.conf /etc/init/ &&
cd /etc/ && sudo wget https://repo1.maven.org/maven2/org/flywaydb/flyway-commandline/4.1.2/flyway-commandline-4.1.2-linux-x64.tar.gz &&
cd /opt/vimond-cms-service/ && sudo chown -R vimond-cms-service:vimond-cms-service vimond-cms-5b7c3e8 vimond-cms-current &&
echo "Installing Flyway......" &&
cd /etc/ && sudo tar -zxvf flyway-commandline-4.1.2-linux-x64.tar.gz -C ./ &&
cd /etc/ && sudo rm flyway-commandline-4.1.2-linux-x64.tar.gz &&
cd /etc/ && sudo chown -R root:vimond-cms-service /etc/flyway-4.1.2 &&
sudo chmod +xx /etc/flyway-4.1.2/flyway &&
echo "Deleting cms downloaded binaries..." &&
cd /opt/vimond-cms-service/ && sudo rm vimond-cms-1.11.0.tgz &&
sudo service vimond-cms-service start
