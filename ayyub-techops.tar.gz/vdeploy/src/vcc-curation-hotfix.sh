cd /opt/vimond-vcc-curation-service && sudo wget http://docs:undocumented@files.vimond.com/vimond_release/1.11.0/vcc/vcc-curation-v1.1.0-120-gf015238.tgz &&
cd /opt/vimond-vcc-curation-service && sudo tar xvf vcc-curation-v1.1.0-120-gf015238.tgz &&
sudo service vimond-vcc-curation-service stop &&
sleep 10 &&
cd /opt/vimond-vcc-curation-service && sudo rm vimond-vcc-curation-current &&
cd /opt/vimond-vcc-curation-service && sudo ln -s vcc-curation-v1.1.0-120-gf015238/server/ vimond-vcc-curation-current &&
cd /opt/vimond-vcc-curation-service && sudo chown -R vimond-vcc-curation-service:vimond-cms-service vcc-curation-v1.1.0-120-gf015238 vimond-vcc-curation-current &&
cd /opt/vimond-vcc-curation-service && sudo rm vcc-curation-v1.1.0-120-gf015238.tgz &&
sudo service vimond-vcc-curation-service start
