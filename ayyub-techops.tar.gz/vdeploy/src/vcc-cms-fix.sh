cd /opt/vimond-cms-service/ && sudo wget https://readonly:AP8PL4Xeyns58vTEE1HZBX1cBQdATj9g5gzuMk@vimond.artifactoryonline.com/vimond/packaged-releases-local/com/vimond/vimond-cms/vimond-cms-5b7c3e8.tgz &&
cd /opt/vimond-cms-service/ && sudo tar xvfz vimond-cms-5b7c3e8.tgz &&
sudo service vimond-cms-service stop &&
sleep 10 &&
cd /opt/vimond-cms-service/ && sudo rm vimond-cms-current &&
cd /opt/vimond-cms-service/ && sudo ln -fns vimond-cms-5b7c3e8 vimond-cms-current &&
cd /opt/vimond-cms-service/ && sudo chown -R vimond-cms-service:vimond-cms-service vimond-cms-5b7c3e8 vimond-cms-current &&
echo "Deleting cms downloaded binaries..." &&
cd /opt/vimond-cms-service/ && sudo rm vimond-cms-5b7c3e8.tgz &&
sudo service vimond-cms-service start
