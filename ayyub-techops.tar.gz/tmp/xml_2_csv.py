import xmlutils
import re
import sys
from xmlutils.xml2csv import xml2csv

def xml_to_csv(xml_file):

	csv_filename = xml_file.replace('xml', "csv")	

	converter = xml2csv(xml_file, csv_filename, encoding="utf-8")

	converter.convert(tag="item")
	
	csv_file = open(csv_filename, "r+")

	line = csv_file.read()

	line = re.sub('{.*?}', '', line)
	
	csv_file.seek(0)

	csv_file.write(line)

	csv_file.truncate()

	csv_file.close()

#========================================================================
if __name__ == "__main__":
        xml_to_csv(sys.argv[1])
