#!/bin/bash

while read -u10 HOST
do
FILENAME=`awk '{print}' publickey`
ssh -i ops-stage.pem ubuntu@$HOST "cd ../ayyub/.ssh; sudo su ayyub echo $FILENAME > authorized_keys"
#echo `awk '{print}' publickey` | ssh -i ops-stage.pem ubuntu@$HOST "sudo cat > ../ayyub/.ssh/authorized_keys"  
#ssh -i ops-stage.pem ubuntu@$HOST "sudo su - ayyub; echo `awk '{print}' publickey` > ../ayyub/.ssh/authorized_keys"
if [ $? != 0 ]
then
echo $HOST >> failping.txt
else
echo $HOST >> sucessping.txt
fi
done 10<hostname.txt
