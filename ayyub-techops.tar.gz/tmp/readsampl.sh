#!/bin/bash

FILENAME=`awk '{print}' publickey`

echo $FILENAME
