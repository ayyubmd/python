#!/bin/bash

for i in `cat hostname.txt`
do
ssh -i ops-stage.pem ubuntu@$i

done
