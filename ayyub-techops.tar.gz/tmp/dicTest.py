import xlrd
import csv
import sys
import os
import smtplib
import mimetypes
from os import sys
from email.mime.multipart import MIMEMultipart
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.text import MIMEText


def excelToCsv(excel_file):

    wb = xlrd.open_workbook(excel_file)
    sh = wb.sheet_by_index(0)
    your_csv_file = open('your_csv_file.csv', 'wb')
    wr = csv.writer(your_csv_file, quoting=csv.QUOTE_ALL)

    for rownum in xrange(sh.nrows):
         wr.writerow(
             list(x.encode('utf-8').strip() if type(x) == type(u'') else x
                  for x in sh.row_values(rownum)))

#========================================================================



#========================================================================
def read_csv():
	f = open("your_csv_file.csv")
	
	count = 0
	for row in csv.reader(f):
		#Condition to ignore first row
		if count != 0:
#		 print row
		 row = filter(None, row)
		 rowlength = len(row)
		 send_mail(row[0], row[1:rowlength])
#		 print len(row)
		count = count+1

#========================================================================
def send_mail(publisher, listofmails):
	
 emailfrom = "mail2ayyub@gmail.com"
 emailto = listofmails
 fileToSend = publisher + "-Watchable-MonthlyReport.xls"
 smtpserv = "smtp.gmail.com:587"
 username = "mail2ayyub@gmail.com"
 password = "Adc143bhf286"

 msg = MIMEMultipart()
 msg["From"] = emailfrom
 msg["To"] = ",".join(emailto)
 msg["Subject"] = 'Monthly Usage & Revenue Reports'
 message = 'Dear Partner\n\nPlease find attached your monthly Usage & Revenue Reports. These numbers include Watchable and available Xfinity platforms.\n\nIf you have any questions please reach out to Matt Tierney or Craig Parks.\n\nBest Regards\nTeam Watchable'

 msg.attach(MIMEText(message))

 ctype, encoding = mimetypes.guess_type(fileToSend)
 if ctype is None or encoding is not None:
    ctype = "application/octet-stream"

 maintype, subtype = ctype.split("/", 1)

 if maintype == "text":
    fp = open(fileToSend)
    # Note: we should handle calculating the charset
    attachment = MIMEText(fp.read(), _subtype=subtype)
    fp.close()
 elif maintype == "image":
    fp = open(fileToSend, "rb")
    attachment = MIMEImage(fp.read(), _subtype=subtype)
    fp.close()
 elif maintype == "audio":
    fp = open(fileToSend, "rb")
    attachment = MIMEAudio(fp.read(), _subtype=subtype)
    fp.close()
 else:
    fp = open(fileToSend, "rb")
    attachment = MIMEBase(maintype, subtype)
    attachment.set_payload(fp.read())
    fp.close()
    encoders.encode_base64(attachment)
 attachment.add_header("Content-Disposition", "attachment", filename=fileToSend)
 msg.attach(attachment)

 server = smtplib.SMTP(smtpserv)
 server.starttls()
 server.login(username,password)
 server.sendmail(emailfrom, emailto, msg.as_string())
 server.quit()


#========================================================================
if __name__ == "__main__":
#    excelToCsv(sys.argv[1])
    read_csv()
    os.remove("your_csv_file.csv")    
    quit()
