import gzip
import sys

def extract_gzip(gzip_file):
	# Open the gzip file
	a = gzip.open(gzip_file)
	
	#Print the content in the file
	# print a.read()
	mystring = a.read().encode('utf-8')
	
	# replace the string pipe with comma
	mystring = mystring.replace(', ', "; ").encode('utf-8')

	mystring = mystring.replace("|", ",").encode('utf-8')

	# print the replace string
	#print mystring

	#create a csv file
	
	gzip_file = gzip_file.replace('.dat.gz', "")

	#print gzip_file

	csv_file = open(gzip_file+".csv", "w")
	
	csv_file.write(mystring)
	
	csv_file.close()

#========================================================================
if __name__ == "__main__":
	extract_gzip(sys.argv[1])
