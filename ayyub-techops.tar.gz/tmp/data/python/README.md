# python
These are my learning experience

-> Convert Excel file to CSV format https://github.com/ayyubmd/python/blob/master/convertExcel2cvs.py

-> Python Script to Stop and Start ec2 Instances in AWS using boto2 https://github.com/ayyubmd/python/blob/master/aws_auto_start.py

-> Python - Lambda Script to stop running instance in AWS Environment https://github.com/ayyubmd/python/blob/master/aws_stop.py

-> Python Script to fetch file from fpt server https://github.com/ayyubmd/python/blob/master/getFile_ftp.py

-> Python Script to send emails with attachments.Excel which has the details of Company and emails
