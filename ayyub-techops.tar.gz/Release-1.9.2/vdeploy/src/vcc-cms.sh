cd /opt/vimond-cms-service/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.2/CMS/vimond-cms-1.9.2.tgz &&
cd /opt/vimond-cms-service/ && sudo tar -xzf vimond-cms-1.9.2.tgz &&
sudo service vimond-cms-service stop &&
sleep 4 &&
cd /opt/vimond-cms-service/ && sudo rm vimond-cms-current &&
cd /opt/vimond-cms-service/ && sudo ln -fns vimond-cms-1.9.2 vimond-cms-current &&
cd /etc/init && sudo expect -f /usr/local/share/get.sh home/Release-1.9.2/CMS/ENV/vimond-cms-service.conf &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/videos && sudo mv 109_nordlys2_loop_720p_1000kb.mp4 109_nordlys2_loop_720p_1000kb.mp4-org &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/videos && sudo mv 109_nordlys2_loop_720p.webm 109_nordlys2_loop_720p.webm-org &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/videos && sudo mv aurora.jpg aurora.jpg-org &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/videos && sudo expect -f /usr/local/share/get.sh home/Release-1.9.1/CMS/aurora.jpg &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/javascripts && sudo mv bundle.js bundle.js-org &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/javascripts && sudo expect -f /usr/local/share/get.sh home/Release-1.9.1/CMS/bundle.js &&
sudo apt-get install -y rlwrap &&
cd /tmp && sudo curl https://deb.nodesource.com/node_6.x/pool/main/n/nodejs/nodejs_6.3.1-1nodesource1~trusty1_amd64.deb -O &&
cd /tmp && sudo dpkg -i nodejs_6.3.1-1nodesource1~trusty1_amd64.deb &&
sleep 3 &&
cd /tmp && sudo rm nodejs_6.3.1-1nodesource1~trusty1_amd64.deb &&
cd /opt && sudo chown -R vimond-cms-service:vimond-cms-service vimond-cms-service &&
sudo service vimond-cms-service start &&
sleep 5 &&
echo "Stopping VCC..." &&
sudo service unicorn_GoldenGateVCC2 stop &&
sleep 6 &&
echo "Starting VCC..." &&
sudo service unicorn_GoldenGateVCC2 start &&
sleep 4 &&
sudo service vimond-vcc-curation-service restart &&
sleep 4 &&
sudo service nginx restart &&
sleep 4 &&
sudo service memcached restart
