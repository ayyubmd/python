cd /opt/asset-importer-service && sudo mv config.yml config.yml_`date +%Y-%m-%d` &&
sudo service vimond-asset-importer-service stop &&
sleep 5 &&
cd /opt/asset-importer-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.2/micros/Assetimporter/ENV/config.yml &&
sleep 2 &&
sudo chown -R asset-importer-service:asset-importer-service /opt/asset-importer-service &&
sudo service vimond-asset-importer-service start
