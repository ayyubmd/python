#!/bin/bash
#Deployment script
###################################################
# Author        : Jithesh.Bharathan@cognizant.com
# Date          : 5/11/2016
# Version       : 1.0
# Description   : This scrip can be used to deployments
# Usage         : ./vdeploy.sh <Host IPs separated by ','> <Script to run> <Platform Prod|Techops|Demo3|Preprod>
# Eg.           : ./vdeploy.sh 172.31.26.37 hostname.sh Techops
###################################################
## Configurations
PRODPEM="key/prod.pem"
TECHOPSPEM="key/ops-stage.pem"
DEMO3PEM="key/demo3.pem"
PREPRODPEM=""
USER="ubuntu"
LOGFILE="logs/deploy-`date +'%m-%d-%Y'`.log"
hostcheck="src/hostname.sh"
###################################################
SSH=`which ssh`
SED=`which sed`
# Self deployer
mkdir -p src
mkdir -p tmp/Techops
mkdir -p tmp/Prod
mkdir -p tmp/Demo3
mkdir -p tmp/Preprod
mkdir -p key
mkdir -p logs
if [ ! -e src/hostname.sh ]
then
    echo "hostname" > src/hostname.sh
fi
# Input argument verification
if [ -z "$1" ]
then
    echo "Error:: Wrong Usage!! Arg missing"
    echo "${0} <Host IPs separated by ','> <Script to run> <Platform Prod|Techops|Demo3|Preprod>"
    exit 1
elif [ -z "$2" ]
then
    echo "Error:: Wrong Usage!! 2nd and 3rd Arg missing"
    echo "${0} <Host IPs separated by ','> <Script to run> <Platform Prod|Techops|Demo3|Preprod>"
    exit 1
elif [ -z "$3" ]
then
    echo "Error:: Wrong Usage!! 3rd Arg missing"
    echo "${0} <Host IPs separated by ','> <Script to run> <Platform Prod|Techops|Demo3|Preprod>"
    exit 1
# Deployment configuration file Update
elif [ -r "src/$2" ]
then
    hosts=$(echo $1 | tr "," "\n")
    script=$2
    scripts="src/${script}"
    platform=$3
    if [[ "${platform}" == "Techops" && -f ${TECHOPSPEM} ]]
    then
        PEM=${TECHOPSPEM}
        ${SED} -e "s/ENV/Techops/g" ${scripts} > tmp/Techops/${script}
        truescript="tmp/Techops/${script}"
    elif [[ "${platform}" == "Prod" && -f ${PRODPEM} ]]
    then
        PEM=${PRODPEM}
        ${SED} -e "s/ENV/Prod/g" ${scripts} > tmp/Prod/${script}
        truescript="tmp/Prod/${script}"
    elif [[ "${platform}" == "Demo3" && -f ${DEMO3PEM} ]]
    then
        PEM=${DEMO3PEM}
        ${SED} -e "s/ENV/Demo3/g" ${scripts} > tmp/Demo3/${script}
        truescript="tmp/Demo3/${script}"
    elif [[ "${platform}" == "Preprod" && -f ${PREPRODPEM} ]]
    then
        PEM=${PREPRODPEM}
        ${SED} -e "s/ENV/Preprod/g" ${scripts} > tmp/Preprod/${script}
        truescript="tmp/Preprod/${script}"
    else
        PEM=" "
        echo "Error:: PEM Key not found or Platform with name '${platform}'!!!"
        exit 1
    fi
# Deployment process starts here
    for addr in $hosts
    do
        echo "" >> ${LOGFILE}
        echo "----- Started with Host ${addr} -----" | tee -a ${LOGFILE}
        echo "`date`" >> ${LOGFILE}
        echo "Server IP: ${addr}"
        HOSTNAME=`${SSH} -i ${PEM} -l ${USER} ${addr} "bash -s" -- < ${hostcheck}`
        echo "Server Host Name: ${HOSTNAME}"
        echo "Script going to execute: ${script}"
        i=0
        while [ $i -lt 1 ]
        do
            echo -n "Do you want to run upgrade on above server? ( y or n )-> "
            read text
            if [ $text == "y" ]
            then
                i=2
                ${SSH} -i ${PEM} -l ${USER} ${addr} "bash -s" -- < ${truescript} 2>&1 | tee -a ${LOGFILE}
            elif [ $text == "n" ]
            then
                i=2
                echo "Skipping Host ${addr}" | tee -a ${LOGFILE}
            else
                i=0
            fi
        done

        echo "`date`" >> ${LOGFILE}
        echo "----- Ends with Host ${addr} --------" | tee -a ${LOGFILE}
        echo "" >> ${LOGFILE}
    done
else
    echo "Error:: Deployment Script '$2' not found in src/!!"
fi
