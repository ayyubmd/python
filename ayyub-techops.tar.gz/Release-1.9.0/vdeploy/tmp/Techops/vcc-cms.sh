sudo apt-get -y install rlwrap &&
sleep 2 &&
cd /home/ubuntu && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/CMS/nodejs_4.2.3-1nodesource1-trusty1_amd64.deb &&
cd /home/ubuntu && sudo dpkg -i nodejs_4.2.3-1nodesource1-trusty1_amd64.deb &&
sleep 2 &&
sudo useradd -s /bin/bash -m -d /opt/vimond-cms-service vimond-cms-service &&
cd /opt/vimond-cms-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/CMS/vimond-cms-1.9.0.tar.gz &&
cd /opt/vimond-cms-service && sudo tar xvfz vimond-cms-1.9.0.tar.gz &&
cd /opt/vimond-cms-service && sudo ln -s vimond-cms-1.9.0 vimond-cms-current &&
sudo mkdir /var/log/vimond-cms-service &&
cd /etc/init && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/CMS/Techops/vimond-cms-service.conf &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/videos && sudo mv 109_nordlys2_loop_720p_1000kb.mp4 109_nordlys2_loop_720p_1000kb.mp4-org &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/videos && sudo mv 109_nordlys2_loop_720p.webm 109_nordlys2_loop_720p.webm-org &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/videos && sudo mv aurora.jpg aurora.jpg-org &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/videos && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/CMS/aurora.jpg &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/javascripts && sudo mv bundle.js bundle.js-org &&
cd /opt/vimond-cms-service/vimond-cms-current/public/cms/javascripts && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/CMS/bundle.js &&
sudo chown -R vimond-cms-service:vimond-cms-service /opt/vimond-cms-service &&
sudo chown -R vimond-cms-service:vimond-cms-service /var/log/vimond-cms-service &&
sudo chmod ug=rw,o=r /etc/init/vimond-cms-service.conf &&
sudo service vimond-cms-service start
