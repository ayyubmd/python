sudo stop vimond-upload-service &&
sleep 2 &&
cd /opt/vimond-upload-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/Upload/vimond-upload-service-2.0.3-9-g4fa2d65.b53.jar &&
sudo rm /opt/vimond-upload-service/vimond-upload-service.jar &&
cd /opt/vimond-upload-service && sudo ln -s vimond-upload-service-2.0.3-9-g4fa2d65.b53.jar vimond-upload-service.jar &&
sudo chown -R vimond-upload-service:vimond-upload-service /opt/vimond-upload-service &&
sudo start vimond-upload-service
