sudo adduser --home /opt/vimond-image-bank-service vimond-image-bank-service --ingroup vimond-api --disabled-password &&
cd /opt/vimond-image-bank-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Imagebank/vimond-image-bank-service-1.0.0.jar &&
cd /opt/vimond-image-bank-service && sudo ln -s vimond-image-bank-service-1.0.0.jar vimond-image-bank-service.jar &&
sudo mkdir /var/log/vimond-image-bank-service &&
cd /etc/init && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Imagebank/vimond-image-bank-service.conf &&
cd /opt/vimond-image-bank-service/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Imagebank/Techops/config.yml &&
cd /opt/vimond-image-bank-service/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Imagebank/jvm.conf &&
sudo chown -R vimond-image-bank-service:vimond-api /opt/vimond-image-bank-service &&
sudo chown -R vimond-image-bank-service:vimond-api /var/log/vimond-image-bank-service &&
sudo chmod ug=rw,o= /etc/init/vimond-image-bank-service.conf &&
cd /opt/vimond-image-bank-service && sudo java -jar vimond-image-bank-service.jar db migrate config.yml &&
sudo service vimond-image-bank-service start
