sudo service vimondImageService stop &&
sleep 2 &&
cd /home/deploy-vis && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Image/vimondImageService-2.0.21.zip &&
cd /home/deploy-vis && sudo unzip vimondImageService-2.0.21.zip &&
cd /home/deploy-vis/VimondImageService-2.0.21 && sudo mkdir logs &&
cd /home/deploy-vis && sudo rm vimondimageservice-current &&
cd /home/deploy-vis && sudo ln -s VimondImageService-2.0.21 vimondimageservice-current &&
cd /home/deploy-vis && sudo cp VimondImageService-2.0.20/start.sh VimondImageService-2.0.21/start.sh &&
cd /home/deploy-vis && sudo cp VimondImageService-2.0.20/stop.sh VimondImageService-2.0.21/stop.sh &&
cd /home/deploy-vis && sudo cp VimondImageService-2.0.20/config.conf VimondImageService-2.0.21/config.conf &&
cd /home/deploy-vis && sudo chown -R deploy-vis:deploy-vis VimondImageService-2.0.21 &&
sleep 2 &&
sudo service vimondImageService start
