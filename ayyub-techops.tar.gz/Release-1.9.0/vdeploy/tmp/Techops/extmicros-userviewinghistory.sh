sudo stop vimond-userviewinghistory-service &&
sleep 2 &&
cd /opt/vimond-userviewinghistory-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Userviewinghistory/vimond-userviewinghistory-service-2.0.2.jar &&
cd /opt/vimond-userviewinghistory-service && sudo rm vimond-userviewinghistory-service.jar &&
cd /opt/vimond-userviewinghistory-service && sudo ln -s vimond-userviewinghistory-service-2.0.2.jar vimond-userviewinghistory-service.jar  &&
cd /opt/ && sudo chown -R vimond-userviewinghistory:vimond-userviewinghistory vimond-userviewinghistory-service &&
sleep 2 &&
sudo start vimond-userviewinghistory-service
