sudo stop vimond-rating-service &&
sleep 2 &&
cd /opt/vimond-rating-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Rating/vimond-rating-service-1.2.2-1-g384b5c7-SNAPSHOT31.jar &&
cd /opt/vimond-rating-service && sudo rm vimond-rating-service.jar &&
cd /opt/vimond-rating-service && sudo ln -s vimond-rating-service-1.2.2-1-g384b5c7-SNAPSHOT31.jar vimond-rating-service.jar &&
cd /opt/ && sudo chown -R vimond-rating-service:vimond-api vimond-rating-service &&
sudo start vimond-rating-service
