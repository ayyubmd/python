sudo stop vimond-oauth &&
sleep 2 &&
cd /opt/vimondoauthwebportal && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Oauth/vimond-oauth-service-1.2.0-6-g0fc990b.b7.jar &&
cd /opt/vimondoauthwebportal && sudo rm vimond-oauth.jar &&
cd /opt/vimondoauthwebportal && sudo ln -s vimond-oauth-service-1.2.0-6-g0fc990b.b7.jar vimond-oauth.jar &&
cd /opt/ && sudo chown -R vimondoauthwebportal:vimond-api vimondoauthwebportal &&
sudo start vimond-oauth