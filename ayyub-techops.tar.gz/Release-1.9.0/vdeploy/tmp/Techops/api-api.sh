sudo service tomcat7 stop &&
sleep 2 &&
sudo rm -rf /usr/local/tomcat/webapps/api &&
sudo mv /usr/local/tomcat/webapps/api.war /usr/local/tomcat/webapps/api.war_`date +"%m-%d-%Y"` &&
cd /usr/local/tomcat/webapps/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/api/core-api-web-standalone-2.2.1-18-g833e726.b947.war &&
cd /usr/local/tomcat/webapps/ && sudo mv core-api-web-standalone-2.2.1-18-g833e726.b947.war api.war &&
sudo chown -R tomcat:tomcat /usr/local/tomcat/webapps &&
sudo java -jar /usr/local/tomcat/webapps/api.war db migrate --non-interactive --settings /usr/local/tomcat/conf/vimond_api_settings.properties &&
sudo service tomcat7 start
