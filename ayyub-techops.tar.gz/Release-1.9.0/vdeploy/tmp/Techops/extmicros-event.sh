sudo stop vimond-event-service &&
sleep 2 &&
cd /opt/vimond-event-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Event/vimond-eventservice-3.0.1-12-g4f0e7f6.b224.jar &&
cd /opt/vimond-event-service && sudo rm vimond-event-service.jar &&
cd /opt/vimond-event-service && sudo ln -s vimond-eventservice-3.0.1-12-g4f0e7f6.b224.jar vimond-event-service.jar &&
cd /opt/ && sudo chown -R vimond-event-service:vimond-event-service vimond-event-service &&
sleep 2 &&
sudo start vimond-event-service
