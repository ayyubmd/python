sudo stop vimond-search-service &&
sleep 2 &&
cd /opt/vimond-search-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Search/vimond-search-service-2.0.4.jar &&
cd /opt/vimond-search-service && sudo rm vimond-search-service.jar &&
cd /opt/vimond-search-service && sudo ln -s vimond-search-service-2.0.4.jar vimond-search-service.jar  &&
cd /opt/ && sudo chown -R vimond-search-service:vimond-api vimond-search-service &&
sudo start vimond-search-service