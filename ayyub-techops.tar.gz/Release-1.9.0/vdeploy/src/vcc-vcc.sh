sudo service unicorn_GoldenGateVCC2 stop &&
sleep 2 &&
sudo apt-get -y install cmake pkg-config &&
sleep 2 &&
cd /home/sites/GoldenGateVCC2/releases/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/vcc-rails-1.9.0.tar.gz &&
cd /home/sites/GoldenGateVCC2/releases/ && sudo tar zxf vcc-rails-1.9.0.tar.gz &&
cd /home/sites/GoldenGateVCC2/releases/20160511123401/config && sudo mv settings.yml settings.yml_bak &&
cd /home/sites/GoldenGateVCC2/shared/config/ && sudo mv settings.yml settings.yml_`date +"%d-%m-%Y"`
cd /home/sites/GoldenGateVCC2/shared/config/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/ENV/settings.yml &&
cd /home/sites/GoldenGateVCC2/releases/20160511123401/config && sudo ln -s /home/sites/GoldenGateVCC2/shared/config/settings.yml &&
cd /home/sites/GoldenGateVCC2/releases/20160511123401/config && sudo mv application.yml application.yml_bak &&
cd /home/sites/GoldenGateVCC2/releases/20160511123401/config && sudo ln -s /home/sites/GoldenGateVCC2/shared/config/application.yml &&
cd /home/sites/GoldenGateVCC2/releases/20160511123401 && sudo mv log log_bak &&
cd /home/sites/GoldenGateVCC2/releases/20160511123401 && sudo ln -s /home/sites/GoldenGateVCC2/shared/log &&
cd /home/sites/GoldenGateVCC2/releases/20160511123401 && sudo mkdir -p tmp/cache &&
cd /home/sites/GoldenGateVCC2/releases/20160511123401/tmp && sudo ln -s /home/sites/GoldenGateVCC2/shared/pids &&
sudo chown -R gg_deployer:gg_deployer /home/sites/GoldenGateVCC2/releases/20160511123401 &&
sudo chown -R gg_deployer /var/opt/rbenv/versions/2.1.2/lib/ruby/gems/2.1.0 &&
sudo -S su - gg_deployer -c "cd /home/sites/GoldenGateVCC2/releases/20160511123401 && bundle install --without development test" &&
cd /home/sites/GoldenGateVCC2/ && sudo rm current &&
cd  /home/sites/GoldenGateVCC2/ && sudo -S su -c "ln -s /home/sites/GoldenGateVCC2/releases/20160511123401/ current" -s /bin/sh gg_deployer &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/approval-1.9.0.tar.gz &&
cd /tmp && sudo tar zxf approval-1.9.0.tar.gz -C /home/sites &&
sudo chown -R www-data:www-data /home/sites/approval-1.9.0 &&
cd /home/sites/ && sudo rm  approval &&
cd /home/sites/ && sudo ln -s approval-1.9.0 approval &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/vcc-content-organizer-1.9.0.tar.gz &&
cd /tmp && sudo tar zxf vcc-content-organizer-1.9.0.tar.gz -C /home/sites &&
sudo chown -R www-data:www-data /home/sites/vcc-content-organizer-1.9.0 &&
cd /home/sites/ && sudo rm  organizer &&
cd /home/sites/ && sudo ln -s vcc-content-organizer-1.9.0 organizer &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/video-monitoring-1.9.0.tar.gz &&
cd /tmp && sudo tar zxf video-monitoring-1.9.0.tar.gz -C /home/sites &&
cd /home/sites/ && sudo rm monitoring &&
sudo chown -R www-data:www-data /home/sites/video-monitoring-1.9.0 &&
cd /home/sites/ && sudo ln -s video-monitoring-1.9.0 monitoring &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/user-profile-1.9.0.tar.gz &&
cd /tmp && sudo tar xf user-profile-1.9.0.tar.gz -C /home/sites &&
sudo chown -R www-data:www-data /home/sites/user-profile-1.9.0 &&
cd /home/sites/ && sudo rm userprofile &&
cd /home/sites/ && sudo ln -s user-profile-1.9.0 userprofile &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/vcc-branding-1.9.0.tar.gz &&
cd /tmp && sudo tar xf vcc-branding-1.9.0.tar.gz -C /home/sites &&
cd /home/sites/vcc-branding-1.9.0/branding && sudo mv svg-logo.svg svg-logo.svg-org &&
cd /home/sites/vcc-branding-1.9.0/branding && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/svg-logo.svg &&
sudo chown -R www-data:www-data /home/sites/vcc-branding-1.9.0  &&
cd /home/sites/ && sudo rm common &&
cd /home/sites/ && sudo ln -s vcc-branding-1.9.0 common &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/vcc-embed-1.9.0.tar.gz &&
cd /tmp && sudo tar xf vcc-embed-1.9.0.tar.gz -C /home/sites &&
sudo chown -R www-data:www-data /home/sites/vcc-embed-1.9.0 &&
cd /home/sites/ && sudo rm embed &&
cd /home/sites/ && sudo ln -s vcc-embed-1.9.0 embed &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/editorial-1.9.0.tar.gz &&
cd /tmp && sudo tar zxf editorial-1.9.0.tar.gz -C /home/sites &&
sudo chown -R www-data:www-data /home/sites/editorial-1.9.0 &&
cd /home/sites/ && sudo rm  editorial &&
cd /home/sites/ && sudo ln -s editorial-1.9.0 editorial &&
cd /home/sites/GoldenGateVCC2/shared && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/set_feature_toggles.sh &&
sudo chmod a+x /home/sites/GoldenGateVCC2/shared/set_feature_toggles.sh &&
cd /home/sites/editorial && sudo ../GoldenGateVCC2/shared/set_feature_toggles.sh lib.js &&
cd /home/sites/organizer && sudo ../GoldenGateVCC2/shared/set_feature_toggles.sh lib.js &&
cd /etc/nginx/sites-enabled && sudo mv GoldenGateVCC2 /etc/nginx/GoldenGateVCC2-`date +"%d-%m-%Y"` &&
cd /etc/nginx/sites-enabled && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/ENV/GoldenGateVCC2 &&
cd /home/sites/ && sudo cp /etc/init.d/unicorn_GoldenGateVCC2 . &&
cd /etc/init.d/ && sudo rm unicorn_GoldenGateVCC2 &&
cd /etc/init.d/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/VCC/unicorn_GoldenGateVCC2 &&
cd /etc/init.d/ && sudo chmod a+x unicorn_GoldenGateVCC2 &&
sudo service unicorn_GoldenGateVCC2 start &&
sleep 2 &&
sudo service nginx restart

