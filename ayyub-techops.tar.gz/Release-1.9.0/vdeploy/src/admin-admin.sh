sudo service tomcat7 stop &&
sleep 2 &&
sudo mv /usr/local/tomcat/webapps/ROOT.war /usr/local/tomcat/ROOT.war_`date +"%m-%d-%Y"` &&
sudo rm -rf /usr/local/tomcat/webapps/ROOT &&
cd /usr/local/tomcat/webapps/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/admin/admin-4.0.7-1-gd794062.b68.war &&
cd /usr/local/tomcat/webapps/ && sudo mv admin-4.0.7-1-gd794062.b68.war ROOT.war &&
sudo service tomcat7 start
