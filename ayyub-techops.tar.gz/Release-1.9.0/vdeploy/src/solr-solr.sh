sudo stop solr &&
cd /opt/solr/vimond/lib/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/solr/vimond-solr.jar &&
cd /opt/ && sudo expect -f /usr/local/share/get.sh /home/Release-1.9.0/solr/ENV/solrconf.tgz &&
cd /opt/ && sudo expect -f /usr/local/share/get.sh /home/Release-1.9.0/solr/ENV/solrconfig.sh &&
cd /opt/ && sudo tar xzf solrconf.tgz &&
cd /opt/solrconf/adminSearch/ && sudo cp -r * /opt/solr/vimond/solr/adminSearch/conf &&
cd /opt/solrconf/userSearch/ && sudo cp -r * /opt/solr/vimond/solr/userSearch/conf &&
cd /opt/ && sudo bash solrconfig.sh &&
sleep 2 &&
sudo start solr
