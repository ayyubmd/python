sudo stop vimond-video-monitoring-service &&
sleep 2 &&
cd /opt/vimond-video-monitoring-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/micros/Videomonitoring/vimond-video-monitoring-service-3.0.0-11-gf39bb30.b51.jar &&
sudo rm /opt/vimond-video-monitoring-service/vimond-video-monitoring-service.jar &&
cd /opt/vimond-video-monitoring-service && sudo ln -s vimond-video-monitoring-service-3.0.0-11-gf39bb30.b51.jar vimond-video-monitoring-service.jar &&
cd /opt/vimond-video-monitoring-service && sudo java -jar vimond-video-monitoring-service-3.0.0-11-gf39bb30.b51.jar db migrate config.yml &&
sudo chown -R vimond-video-monitoring-service:vimond-video-monitoring-service /opt/vimond-video-monitoring-service &&
sudo start vimond-video-monitoring-service
