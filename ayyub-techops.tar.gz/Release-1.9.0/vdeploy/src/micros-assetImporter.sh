sudo service vimond-asset-importer-service stop &&
sleep 2 &&
sudo mv /opt/asset-importer-service/config.yml /opt/asset-importer-service/config.yml_`date +"%m-%d-%Y"` &&
cd /opt/asset-importer-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/micros/Assetimporter/ENV/config.yml &&
cd /opt/asset-importer-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/micros/Assetimporter/ais-all-in-one-service-3.3.5-SNAPSHOT173.jar &&
sudo rm /opt/asset-importer-service/vimond-asset-importer-service.jar &&
cd /opt/asset-importer-service && sudo -S su -c "ln -s ais-all-in-one-service-3.3.5-SNAPSHOT173.jar vimond-asset-importer-service.jar" -s /bin/sh asset-importer-service &&
sudo chown -R asset-importer-service:asset-importer-service /opt/asset-importer-service &&
sudo service vimond-asset-importer-service start
