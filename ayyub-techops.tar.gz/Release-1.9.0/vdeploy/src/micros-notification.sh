sudo service vimond-notification-service stop &&
sleep 2 &&
cd /opt/vimond-notification-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/micros/Notification/VimondNotificationService-3.0.1-6-g74f0710.b26.jar &&
cd /opt/vimond-notification-service && sudo rm vimond-notification-service.jar &&
cd /opt/vimond-notification-service && sudo ln -s VimondNotificationService-3.0.1-6-g74f0710.b26.jar vimond-notification-service.jar &&
sudo chown -R vimond-notification-service:vimond-notification-service /opt/vimond-notification-service &&
sudo service vimond-notification-service start