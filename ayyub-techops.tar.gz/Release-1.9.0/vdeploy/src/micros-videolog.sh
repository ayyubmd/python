sudo stop vimond-videolog-service &&
sleep 2 &&
sudo mv /opt/vimond-videolog-service/config.yml /opt/vimond-videolog-service/config.yml_`date +"%m-%d-%Y"` &&
cd /opt/vimond-videolog-service/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/micros/Videolog/ENV/config.yml &&
cd /opt/vimond-videolog-service/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/micros/Videolog/vimond-videolog-service-2.0.1-4-gba01bae.b20.jar &&
cd /opt/vimond-videolog-service/ && sudo rm vimond-videolog-service.jar &&
cd /opt/vimond-videolog-service/ && sudo ln -s vimond-videolog-service-2.0.1-4-gba01bae.b20.jar vimond-videolog-service.jar &&
sudo chown -R vimond-videolog-service:vimond-videolog-service /opt/vimond-videolog-service &&
cd /opt/vimond-videolog-service/ && sudo java -jar vimond-videolog-service.jar migrate config.yml &&
sudo start vimond-videolog-service
