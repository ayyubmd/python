sudo stop vimond-gatekeeper-service &&
sleep 2 &&
cd /opt/vimond-gatekeeper/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Gatekeeper/vimond-gatekeeper-service-3.10.125.jar &&
cd /opt/vimond-gatekeeper/ && sudo rm vimond-gatekeeper-service.jar &&
cd /opt/vimond-gatekeeper/ && sudo ln -s vimond-gatekeeper-service-3.10.125.jar vimond-gatekeeper-service.jar &&
cd /opt/vimond-gatekeeper/ && sudo cp config.yml config.yml_`date +"%m-%d-%Y"` &&
cd /opt/vimond-gatekeeper/ && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/externalmicros/Gatekeeper/ENV/config.yml &&
cd /opt/vimond-gatekeeper/ && sudo java -jar vimond-gatekeeper-service.jar migrate config.yml &&
cd /opt/ && sudo chown -R vimond-gatekeeper:vimond-api vimond-gatekeeper &&
sudo start vimond-gatekeeper-service
