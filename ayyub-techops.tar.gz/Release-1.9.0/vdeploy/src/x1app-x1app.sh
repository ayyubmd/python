sudo service varnish stop &&
sleep 2 &&
sudo service tomcat7 stop &&
sleep 2 &&
cd /var/lib/tomcat7/webapps && sudo mv channelstore-webapp.war channelstore-webapp.war-1.1.1 &&
cd /var/lib/tomcat7/webapps && sudo rm -rf channelstore-webapp &&
cd /var/lib/tomcat7/webapps && sudo expect -f /usr/local/share/get.sh home/x1app-releases/watchable-x1app-1.2.0/channelstore-webapp.war &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/x1app-releases/watchable-x1app-1.2.0/watchable-config-1.2.0-bundle.tar.gz &&
cd /tmp && sudo tar -xvf watchable-config-1.2.0-bundle.tar.gz &&
sudo service tomcat7 restart &&
sleep 2 &&
sudo service varnish restart
