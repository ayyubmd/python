cd /opt/fabric/flds/latest/target && sudo ./download.sh http://ec2-54-198-224-135.compute-1.amazonaws.com:8080/job/fabric-develop-fmds/34/artifact/services/metadata/restapi/target/universal/fmds-develop-34.tgz &&
cd /opt/fabric/flds/latest/bin && sudo ./fmds install develop-34 &&
sleep 2 &&
cd /opt/fabric && sudo ./fmdsservice.sh stop &&
sleep 2 &&
cd /opt/fabric/fmds && sudo rm latest &&
sudo ln -s fmds-develop-34 latest
cd /opt/fabric && sudo ./fmdsservice.sh start
