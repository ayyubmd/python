sudo service vimond-audit-logging-service stop &&
sleep 2 &&
cd /opt/vimond-audit-logging-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/micros/Auditlogging/auditlogging-service-2.0.2-17-g3cb52ec.b43.jar &&
cd /opt/vimond-audit-logging-service && sudo rm vimond-audit-logging-service.jar &&
cd /opt/vimond-audit-logging-service && sudo ln -s auditlogging-service-2.0.2-17-g3cb52ec.b43.jar vimond-audit-logging-service.jar &&
sudo chown -R auditloggingservice:auditloggingservice /opt/vimond-audit-logging-service &&
sudo service vimond-audit-logging-service start