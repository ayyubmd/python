sudo stop vimond-event-writer-service &&
sleep 2 &&
cd /opt/vimond-event-writer-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/micros/Eventwriter/vimond-event-writer-service-2.0.1-11-gdbb2af7-SNAPSHOT17.jar &&
cd /opt/vimond-event-writer-service && sudo rm vimond-event-writer-service.jar &&
cd /opt/vimond-event-writer-service && sudo ln -s vimond-event-writer-service-2.0.1-11-gdbb2af7-SNAPSHOT17.jar vimond-event-writer-service.jar &&
cd /opt/ && sudo chown -R vimond-event-writer-service:vimond-api vimond-event-writer-service &&
sudo start vimond-event-writer-service