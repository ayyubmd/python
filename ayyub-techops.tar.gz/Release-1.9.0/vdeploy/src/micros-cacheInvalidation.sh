sudo stop cache-invalidation-service &&
sleep 2 &&
cd /opt/cache-invalidation-service && sudo expect -f /usr/local/share/get.sh home/Release-1.9.0/micros/Cacheinvalidation/cache-invalidation-service-3.0.2-SNAPSHOT17.jar &&
cd /opt/cache-invalidation-service && sudo rm cache-invalidation-service.jar &&
cd /opt/cache-invalidation-service && sudo ln -s cache-invalidation-service-3.0.2-SNAPSHOT17.jar cache-invalidation-service.jar &&
sudo chown -R cache-invalidation-service:vimond-api /opt/cache-invalidation-service &&
sudo start cache-invalidation-service