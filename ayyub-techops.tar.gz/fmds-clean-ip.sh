#!/bin/bash

function showHelp(){
  echo "Provide server name along with port"
}

function flush_cache {
  CACHE_NAME=$1
  echo "Flush Cache = ${CACHE_NAME}"
  echo "http://${BASE_URI}/fmds/admin/caches/${CACHE_NAME}/keys"
  RESPONSE=`curl -X DELETE -H "Connection:close" "http://${BASE_URI}/fmds/admin/                                                                                        caches/${CACHE_NAME}/keys" 2> /dev/null`
  echo "${RESPONSE}"
}
if [ -z $1 ]
then
 echo "Usage: $0 172.31.16.71:9000"
 echo ""
else
  BASE_URI=$1;

  if [ "$BASE_URI" != "" ]; then
        flush_cache http
        flush_cache vimond_objects
        flush_cache vimond_queries
  else
        showHelp
  fi
fi
