#!/bin/python

from PIL import Image
import sys

def convertPng2jpg(pngfile):
     img = Image.open(pngfile)
     jpgFilename = pngfile.replace('.png', '.jpg')
     img.convert('RGBA').save(jpgFilename,"JPEG")

#===================================================================
if __name__ == "__main__":
        convertPng2jpg(sys.argv[1])
