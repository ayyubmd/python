select * from list where tenant = 'gg';
