<form action="#" method="post">
<select name="res">
<option value="Select">Select Resolution</option>
<option value="Main">Main</option>
<option value="Cover_art">Cover_art (1242x1500)</option>
<option value="2to1_logo">2to1_logo (1200x600)</option>
<option value="3to4_logo">3to4_logo (1536x2048)</option>
<option value="1to1_FullColor_1">1to1_FullColor_1 (2400x2400)</option>
<option value="Horizontal_logo">Horizontal_logo (1053x122)</option>
<option value="X2_Gallery_Image_1">X2_Gallery_Image_1 (444x333)</option>
<option value="Horizontal-Lc-Logo">Horizontal-Lc-Logo (1053x122)</option>
<option value="I_logo">I_logo (436x245)</option>
<option value="H1_Logo">H1_Logo (1920x820)</option>
<option value="H2_Cover_Art">H2_Cover_Art (1920x820)</option>
<option value="Horizontal_banner">Horizontal_banner (597x170)</option>
</select>
<input type="submit" name="submit" value="Get Selected Values" />
</form>
<?php
if(isset($_POST['submit'])){
$selectedResolutionName = $_POST['res'];  // Storing Selected Value In Variable

   if($selectedResolutionName != 'Select'){

        $selectedResolutionSize = '';
        $imageFileName = '';

        if ($selectedResolutionName == 'Main'){
            $selectedResolutionSize = '?location=main';
            $imageFileName = 'main';
        }

        if($selectedResolutionName == 'Cover_art'){
            $selectedResolutionSize = '?location=cover_art&width=1242&height=1500';
            $imageFileName = 'CoverArt';
        }
        if($selectedResolutionName == '2to1_logo'){
            $selectedResolutionSize = '?location=2to1_logo&width=1200&height=600';
            $imageFileName = '2to1Logo';
        }
        if($selectedResolutionName == '3to4_logo'){
            $selectedResolutionSize = '?location=3to4_logo&width=1536&height=2048';
            $imageFileName = '3to4Logo';
        }
        if($selectedResolutionName == '1to1_FullColor_1'){
            $selectedResolutionSize = '?location=1to1_FullColor_1&width=2400&height=2400';
            $imageFileName = '1to1FullColor1';
        }
        if($selectedResolutionName == 'Horizontal_logo'){
            $selectedResolutionSize = '?location=horizontal_logo&width=1053&height=122';
            $imageFileName = 'HorizontalLogo';
        }
        if($selectedResolutionName == 'X2_Gallery_Image_1'){
            $selectedResolutionSize = '?location=X2_Gallery_Image_1&width=444&height=333';
            $imageFileName = 'X2GalleryImage';
        }
        if($selectedResolutionName == 'Horizontal-Lc-Logo'){
            $selectedResolutionSize = '?location=horizontal-lc-logo&width=1053&height=122';
            $imageFileName = 'HorizontalLcLogo';
        }
        if($selectedResolutionName == 'I_logo'){
            $selectedResolutionSize = '?location=I_logo&width=436&height=245';
            $imageFileName = 'ILogo';
            }if($selectedResolutionName =='H1_Logo'){
            $selectedResolutionSize = '?location=H1_Logo&width=1920&height=820';
            $imageFileName = 'H1Logo';
        }
        if($selectedResolutionName == 'H2_Cover_Art'){
            $selectedResolutionSize = '?location=H2_Cover_Art&width=1920&height=820';
            $imageFileName = 'H2CoverArt';
        }
        if($selectedResolutionName == 'Horizontal_banner'){
            $selectedResolutionSize = '?location=horizontal_banner&width=597&height=170';
            $imageFileName = 'Horizontalbanner';
        }
    echo "You have selected :" .$selectedResolutionName;
    echo '<br>';
    echo "Selected Resolution Size :" .$selectedResolutionSize . " Image File Name " .$imageFileName ;  // Displaying Selected Value
    }else{
     exit();
    }
    
    //selectedResolutionName is Selected 
    if(selectedResolutionName != ''  ){
     
    }else{
     
    }
}
?>
