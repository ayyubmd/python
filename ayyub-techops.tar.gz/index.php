<?php
// Code starts here..
echo '
    <html>
    <head>
    <title>User Mng Tool</title>
    </head>
    <body >
    <div id="blk-1">
    <form method="get" action="' . $_SERVER['PHP_SELF'] . '">
    <input type="text" name="username" />
    <input type="submit" name="submit" value="submit"/>
    <br>
    ';
ob_start();
error_reporting(E_ALL & ~E_NOTICE);


// Database connection
$db = "(DESCRIPTION=(ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = opsdbnew.cggz8cqf8bw0.us-east-1.rds.amazonaws.com)(PORT = 1521)))(CONNECT_DATA=(SID=opsdbnew)))";

$userVar = $_GET['username'];

getUserDetails($userVar, $db);

function getUserDetails($userVar, $db)
{
    
    $conn = oci_connect("vimond", "watchable", $db);
    
    if (!$conn) {
        $e = oci_error();
        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
    }
    $stid = oci_parse($conn, "select * from USER_PROFILE where EMAIL = '{$userVar}' ");
    
    oci_execute($stid);
    oci_fetch($stid);
    
    
    if ($userVar == '') {
        echo 'Please provide Email Id';
    } else if (isset($_REQUEST["username"]) && oci_result($stid, 'EMAIL') != '') {
        
        //Get the email-id
        $emailRes = oci_result($stid, 'EMAIL');
        
        //Get unique ID from database
        $emailId = oci_result($stid, 'ID');
        echo $emailRes;
        echo " ";
        echo $emailId;
    } else if (isset($_REQUEST["username"]) && oci_result($stid, 'EMAIL') == '') {
        echo 'No Data Found';
    }
    
    //Closing the DB Connection.
    oci_close($conn);
}

function delUser() {

}

echo '
    </form>
    </div>
    </body>';
?>
