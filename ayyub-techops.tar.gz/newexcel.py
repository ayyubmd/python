#!/usr/bin/python

import xlrd

#----------------------------------------------------------------------
def open_file(path):
    """
    Open and read an Excel file
    """
    book = xlrd.open_workbook(path)
    # print number of sheets
    # print book.nsheets
    # print sheet names
    # print book.sheet_names()
    # get the first worksheet
    first_sheet = book.sheet_by_index(0)
    # read a row
    print xrange(first_sheet.nrows)
    for rownum in xrange(first_sheet.nrows):
      print first_sheet.row_values(rownum) | grep -i media

#----------------------------------------------------------------------
if __name__ == "__main__":
    path = "Provider Performance.xls"
    open_file(path)
