sudo apt-get install postgresql-client -y &&
sleep 6 &&
echo "`psql --version` installed" &&
sleep 6 &&
cd /tmp && sudo expect -f /usr/local/share/get.sh home/Release-1.9.3/CMS/psql_update.sql
PGPASSWORD=watchable psql --host opsvccdbnew.cggz8cqf8bw0.us-east-1.rds.amazonaws.com --port 5432 --username=vimond --dbname vccdb < /tmp/psql_update.sql &&
echo "uninstalling postgresql-client..." &&
sleep 6 &&
sudo apt-get remove postgresql-client -y &&
sudo apt-get autoremove
