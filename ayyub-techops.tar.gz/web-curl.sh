while true
do
curl -s http://web.xidio.info/videos/65322
curl -s http://web.xidio.info/shows/12388-a-v-undercover/videos/65321-eric-bachmann-covers-david-bowie-s-heroes
curl -s http://web.xidio.info/shows/12388-a-v-undercover/videos/65320-tacocat-covers-katy-perry-s-roar
curl -s http://web.xidio.info/shows/12388-a-v-undercover
curl -s http://web.xidio.info/shows/12388-a-v-undercover/videos/65323-wye-oak-covers-pat-benatar-announces-big-tour
curl -s http://web.xidio.info/shows/12385-formula-drift-long-beach/videos/65301-formula-drift-2016-streaming-live-on-networka-com-all-season-long
done
