select MA.VALUE,PROGRAM_TYPE_ID,prog_id
from   METADATA_CATEGORY MC, PROGRAM_TYPES_TREE PTT, PROGRAMS P, METADATA_ASSET MA
where  MC.value = '274'
and    MC.name = 'publisher-id'
and    MC.CATEGORY_ID = PTT.ID
AND    PTT.ACTIVATION_STATUS = 'ACTIVE'
AND    PTT.APPROVAL_STATUS like 'APPROVED%'
and    P.published=1 and P.deleted=0
and    PTT.PROGRAM_TYPE_ID = P.TYPE
and    P.prog_id = MA.ASSET_ID
AND    MA.name = 'image-pack';
