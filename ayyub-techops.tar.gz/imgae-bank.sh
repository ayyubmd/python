#!/bin/bash
health_check=`curl http://$1:8149/ping`
case $health_check in
"pong")
echo "healthcheck OK "
exit 0
;;
*)
echo "UNKNOWN - $used_space% of disk space used."
exit 2
;;
esac
