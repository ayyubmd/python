sqlplus64 vimond/watchable@//opsdbnew.cggz8cqf8bw0.us-east-1.rds.amazonaws.com:1521/opsdbnew
#sqlplus64 vimond/watchable@//prdwat.csziq9cqsaej.us-east-1.rds.amazonaws.com:1521/prdwat
