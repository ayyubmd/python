## Open the file with read only permit
f = open('pubdetails')
## Read the first line 
pubname = f.readline().strip()
## If the file is not empty keep reading line one at a time
## till the file is empty
while pubname:
 print pubname
 file = open(pubname + ".csv", "w")
 for sfile in open ('your_csv_file.csv'):
  if pubname in sfile:
   file.write(sfile)
 file.close()
 pubname = f.readline().strip()
f.close()
