import boto3

region = 'us-east-1'

ec2 = boto3.resource('ec2', region_name=region)

ids = []

instances = ec2.instances.filter(
 Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])

for instance in instances:
# print instance.id + " " +instance.state['Name']
 if instance.state['Name']=='running':
  ids = ids + [instance.id]
# ec2.instances.filter(InstanceIds=ids).stop()
# for tag in instance.tags:
#  if tag['Key'] == 'Name':
#   print tag['Value'] + ' stopping'
print ids
